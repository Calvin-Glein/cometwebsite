<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/13/2016
 * Time: 9:53 AM
 */

get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <div class="ui container" id="content">


        <div class="ui grid">
            <div class="five wide column">

                <?php if (has_post_thumbnail()) { ?><img class="ui image rounded large"
                                                         src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>"> <?php } ?>

                <?php if(in_category('faculty')) { ?>
                    <br>
			  
			  
			  

			  			<table class="ui very basic  celled table">
							<!--<thead>
							  <tr><th>Employee</th>
							  <th>Correct Guesses</th>
							</tr></thead>--><!---->
							<tbody>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="write icon"></i>
									<div class="content">
									  Position
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('rank'); ?>
								</td>
							  </tr>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="newspaper icon"></i>
									<div class="content">
									  Research Fields
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  
								  <?php if (have_rows('field')):

												  
												  
												  
												  
												  
												  
												  
												  
                        // loop through the rows of data
                        while (have_rows('field')) : the_row();
                            ?>

                            <?php the_sub_field('research'); ?>
                            <?php
                        endwhile;

                    endif;

                ?>
								  
								  
								  
								</td>
							  </tr>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="mail outline icon"></i>
									<div class="content">
									  Email
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('email'); ?>
								</td>
							  </tr>
							  
							</tbody>
						  </table>

			  
			  
			  
			  
                 

                <?php } else{ ?>
                    <br>
                  <!--  <b>Batch: </b> <?php the_field('batch'); ?> <br>
                    <b>Degree: </b> <?php the_field('degree'); ?> <br>
			        <b>Email: </b> <?php the_field('email'); ?> <br>--><!---->

			  
			  
			  

			  			<table class="ui very basic  celled table">
							<!--<thead>
							  <tr><th>Employee</th>
							  <th>Correct Guesses</th>
							</tr></thead>--><!---->
							<tbody>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="university icon"></i>
									<div class="content">
									  Batch
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('batch'); ?>
								</td>
							  </tr>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="student icon"></i>
									<div class="content">
									  Degree
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('degree'); ?>
								</td>
							  </tr>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="mail outline icon"></i>
									<div class="content">
									  Email
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('email'); ?>
								</td>
							  </tr>
							  
							</tbody>
						  </table>


                    <?php
                }
                ?>
            </div>
            <div class="eleven wide column">
                <h1 class="ui header "><?php echo get_the_title(); ?></h1>
			  	<div class = "ui divider"></div>

                <div style = "text-align: justify; text-justify: inter-word;"> <?php the_content(); ?> </div>

                <?php if (in_category('faculty')) { ?>



                    <h2 class="ui header">Papers</h2>
					<div class = "ui divider"></div>


                    <?php
                    $paperz = new WP_Query(array(
                        'connected_type' => 'researched', // the name of your connection type
                        'connected_items' => get_queried_object(),
                        'nopaging' => true,
                    ));


                    p2p_type('researched')->each_connected($paperz, array(), 'members');

                    if ($paperz->have_posts()) : ?>
			  
			                      <div class="ui three column grid">


                        <?php while ($paperz->have_posts()) :
                            $paperz->the_post(); ?>


                            <div class="column">
                                <div class="ui card">
								  
								   <div class="content">
									  <div class="header"><?php echo the_title(); ?></div>
									</div>
																	
                                    <div class="content">
                                        <div class="description" style = "text-align: justify; text-justify: inter-word;">
                                            <?php echo get_the_content(); ?>
                                        </div>
                                    </div>
                                    <a href="<?php the_field('link'); ?>" class="ui bottom attached button">
                                        View Paper

                                    </a>
                                </div>


                            </div>

                                  

                        <?php endwhile; ?> </div> <?php endif; 
                } ?>
			 				  

                <h2 class="ui header">Current Projects</h2>
				<div class = "ui divider"></div>

				  	
				   <table class="ui celled very padded table sortable">
					<thead>
					  <tr><th class="sorted ascending">Title</th>
					  <th class = "sorted ascending">Role</th>
					</tr></thead>
					<tbody>


                    <?php
                    // Find connected weeks
                    $connected = new WP_Query(array(
                        'connected_type' => 'working', // the name of your connection type
                        'connected_items' => get_queried_object(),
                        'nopaging' => true,
					  	'orderby' => 'title',
						'order'   => 'ASC',
                    ));


                    p2p_type('working')->each_connected($connected, array(), 'members');

                    if ($connected->have_posts()) : ?>

                        <?php while ($connected->have_posts()) :
                            $connected->the_post(); ?>

				 
				  
				 
					  <tr class = "clickable" onclick="location.href='<?php the_permalink(); ?>'"v>
						<td>
							<div class="content">
							  <?php echo the_title(); ?>
						  </div>
						</td>
						<td>
						  <?php echo p2p_get_meta($post->p2p_id, 'role', true); ?>
						</td>
					  </tr>
                        <?php endwhile; ?>
                        <?php
                        // Prevent weirdness
                        wp_reset_postdata();
                    endif;
                    ?>
					  
					 </tbody>
				  </table>
				  
			
			  
		
			     <h2 class="ui header">Past Projects</h2>
				<div class = "ui divider"></div>
			  
			   <table class="ui celled very padded table sortable">
					<thead>
					  <tr><th class="sorted ascending">Title</th>
					  <th class = "sorted ascending">Role</th>
					</tr></thead>
					<tbody>


                   <?php if (have_rows('recent_projects')):

                                        $j=0;
                                        // loop through the rows of data
                                        while (have_rows('recent_projects')) : the_row();

                                            // display a sub field value
                                            ?>
				 
					  <tr class = "clickable" onclick="location.href='<?php the_sub_field('permalink');?>'"v>
						<td>
							<div class="content">
							  <?php the_sub_field('project_title');?>
						  </div>
						</td>
						<td>
						  <?php the_sub_field('role');?>
						</td>
					  </tr>
                        <?php endwhile; ?>
                        <?php
                        // Prevent weirdness
                        wp_reset_postdata();
                    endif;
                    ?>
					  
					 </tbody>
				  </table>
			  
			  
			  
			  
			  
			  
			  
			    <script>
				  $('table').tablesort();
			  </script>
			  
			  
			  
            </div>

        </div>

		  <br>
		  <br>
		  

    </div>

    <?php
endwhile;
endif;
get_footer();
?>