<br>
<br>
<br>
<br>
<br>
<br>
<footer class="site-footer footer">

    <div class="ui container ">
        <div class="ui grid">
		  
		  <div class = "four wide column">
			<div class = "ui grid">
			  
			   <div class="sixteen wide column">
				 <img class="ui image centered medium"
				src="http://128.199.182.88:8080/wp-content/uploads/2017/01/Logos.png">   
            	</div>
			<!--  <div class="five wide column">
				 <img class="ui image centered small"
				src="http://128.199.182.88:8080/wp-content/uploads/2017/01/COMET.png">   
               </div>--><!---->
			  
			  
			</div>
			
			
			<div class = "ui grid">
			  
			   <div class="sixteen wide column address">
				 <div style = "font-size: 11.5px;"> Center for Complexity and Emerging Technologies</div>
				 <div style = "font-size: 11.5px;"> Room 406, Gokongwei Hall</div>
				 <div style = "font-size: 11.5px;"> De La Salle University</div>
				 <div style = "font-size: 11.5px;"> 2401 Taft Avenue, Malate, Manila</div>
				 
               </div>
			  
			  
			  <div class="one wide column">
				  
            	</div>
			</div>
		  </div>  
		  
		  
		  
		  
		  
		   <div class="one wide column inverted divided">
            <div class="ui stackable grid inverted divided">
                    <div class="eight wide column left">
					  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br>
                    </div>
                    <div class="eight wide column right">
                	</div>
            </div>
		  	</div>
		  
		 
		  
		  <div class = "eleven wide column ui grid">
			<div class =  "ui grid">
            <div class="four wide column">
                <h3 class="ui header"><a href="<?php bloginfo('url'); ?>" class="headlink">COMET</a></h3>
                <a href="<?php bloginfo('url'); ?>" class="whitelink"><h5 class="ui header whitelink">Home</h5></a>
                <a href="<?php bloginfo('url'); ?>/about-us" class="whitelink"><h5 class="ui header whitelink">About Us</h5></a>
                <a href="<?php bloginfo('url'); ?>/events" class="whitelink"><h5 class="ui header whitelink">Events</h5></a>
                <a href="<?php bloginfo('url'); ?>/news" class="whitelink"><h5 class="ui header whitelink">News</h5></a>
			    <a href="<?php bloginfo('url'); ?>/support" class="whitelink"><h5 class="ui header whitelink">Support</h5></a>

            </div>
            <div class="four wide column">
                <h3 class="ui header"><a href="<?php bloginfo('url'); ?>/projects" class="headlink">Projects</a></h3>
                <a href="<?php bloginfo('url'); ?>/projects/complex-systems" class="whitelink"><h5 class="ui header whitelink">Complex Systems</h5></a>
                <a href="<?php bloginfo('url'); ?>/projects/seamless-interfaces" class="whitelink"><h5 class="ui header whitelink">Seamless Interfaces</h5></a>
			    <a href="<?php bloginfo('url'); ?>/projects/civic-services" class="whitelink"><h5 class="ui header whitelink">Civic Services</h5></a>

            </div>
            <div class="four wide column">
                <h3 class="ui header"><a href="<?php bloginfo('url'); ?>/people/faculty" class="headlink">People</a></h3>
                <a href="<?php bloginfo('url'); ?>/people/faculty" class="whitelink"><h5 class="ui header whitelink">Faculty</h5></a>
                <a href="<?php bloginfo('url'); ?>/people/cohorts" class="whitelink"><h5 class="ui header whitelink">Cohorts</h5></a>
                <a href="<?php bloginfo('url'); ?>/people/alumni" class="whitelink"><h5 class="ui header whitelink">Alumni</h5></a>
            </div>
            <div class="four wide column">
                <h3 class="ui header headlink">Networks</h3>
					<a href="https://github.com/dlsucomet" class="ui mini image ">
					  <img src="http://128.199.182.88:8080/wp-content/uploads/2017/01/github-1.png">
					</a>
					<a href="https://www.facebook.com/dlsucomet/" class="ui mini image"> 
					  <img src="http://128.199.182.88:8080/wp-content/uploads/2017/01/facebook-1.png">
					</a>
            </div>
		  
		  
		  </div>
			
			 <div class="sixteen wide column address">
			   <br>
			   <div style = "font-size: 12px;"><i class="copyright icon"></i>Center for Complexity and Emerging Technologies. All rights reserved. This site is maintained by the COMET Web Team. </div>
			
				 
               </div>
			
		  </div>
		  

		 
        </div>

    </div>


</footer>
</body>
</html>