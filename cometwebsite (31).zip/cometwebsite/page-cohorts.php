<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/11/2016
 * Time: 12:18 AM
 */

get_header();
//?>

<div class="ui container" id="content">

    <div class="ui basic segment headingc">
        <h1 class="ui header headerc">
            <?php $temp = get_the_title();
            echo "People"; ?>
        </h1>
        <div class="headingsubc">
            <div class="ui buttons">
	
				 
					 <!-- <a href="<?php the_permalink($post->post_parent); ?>">All</a>--><!---->
					  <?php $this_page_id = $wp_query->post->ID; ?>
	  
					  <?php query_posts(array('showposts' => 20, 'post_parent' => $post->post_parent, 'post_type' => 'page', 'orderby' => 'menu_order'));
					  while (have_posts()) {
						  the_post(); ?>
		
					<!--<div class="ui  button <?php if (strcmp(get_the_title(), $temp) != 0) echo " animated basic"; ?> <?php if (strcmp(get_the_title(), $temp) == 0) echo "positive activeButton"; ?>" tabindex="0" onclick="location.href = '<?php the_permalink(); ?>';">
						  <div class="visible content"><?php the_title(); ?></div>
					  
					  		<?php if (strcmp(get_the_title(), $temp) != 0) echo "<div class=\"hidden content\"><i class=\"right chevron right icon\"></i></div>"; ?>
						 
					</div>--><!---->
						 <button class="ui button  <?php if (strcmp(get_the_title(), $temp) != 0) echo "basic "; ?> <?php if (strcmp(get_the_title(), $temp) == 0) echo "positive activeButton"; ?>" onclick="location.href = '<?php the_permalink(); ?>';"><?php the_title(); ?></button>

			
						  
					  <?php }
					  wp_reset_postdata(); ?>
				  
			</div>
        </div>
    </div>
    <div class="ui fitted divider"></div>

    <div class="ui five column grid" style="margin-top: 30px">
        <?php
        wp_reset_query();
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $loop = new WP_Query(array('post_type' => 'members', 'category_name' => 'cohorts', 'posts_per_page' => 10, 'paged' => $paged,  'orderby' => 'title','order' => 'ASC'));
        p2p_type('working')->each_connected($loop, array(), 'project');
        if ($loop->have_posts()) :
        while ($loop->have_posts()) :
            $loop->the_post(); ?>
            <div class="column">

                <!--                    <div class="ui link cards">-->
                <div class="ui card" >
                    <?php if (has_post_thumbnail()) { ?>
				  
				  <div class="blurring dimmable image">
					  <div class="ui dimmer">
						<div class="content">
						  <div class="center">
							<div class="ui inverted button" onclick="location.href='<?php the_permalink(); ?>'">View Profile</div>
						  </div>
						</div>
					  </div>
						  <img style = "width: auto; height: auto; " class src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>">
                        
				  </div>
                    <?php } ?>
                    <div class="content clickable" onclick="location.href='<?php the_permalink(); ?>'">
                        <h1 class="header" href="<?php echo the_permalink(); ?>"><?php echo the_title(); ?></h1>
                       <!-- <div class="meta">
                            <a><?php $categories = get_the_category();
                                echo esc_html($categories[0]->name); ?></a>
                        </div>
                        <div class="description">
                            <?php echo get_the_excerpt(); ?>
</div>--><!---->
                    </div>
                    <div class="extra content clickable" onclick="location.href='<?php the_permalink(); ?>'">
                              <span class="right floated">
                                  <?php

                                  $count = sizeof($post->project);
                                  //                                  foreach ( $post->project as $post ) : setup_postdata( $post );
                                  //                                      $count = $count+1;
                                  //                                  endforeach;

                                  //                                  wp_reset_postdata();

                                  wp_reset_postdata();

                                  if ($count != 1) echo $count . " Projects";
                                  else echo $count . " Project";
                                  ?>
                              </span>
                    </div>
                </div>

                <!--                    </div>-->
            </div>
        <?php endwhile; ?>

    </div>
  
  <script>
	
	$('.image').dimmer({
  on: 'hover'
});
	
  </script>

    <div class="ui basic very padded center aligned segment ">
        <?php
        if (function_exists(custom_pagination)) {
            custom_pagination($loop->max_num_pages, "", $paged);
        }

        endif;
        wp_reset_postdata();
        ?>
    </div>


</div>


<?php
wp_reset_postdata();
get_footer();
?>
