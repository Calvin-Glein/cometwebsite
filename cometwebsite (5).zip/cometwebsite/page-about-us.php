<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/13/2016
 * Time: 9:53 AM
 */

get_header();
?>


<?php //if (have_posts()) : ?>
    <!--    --><?php //while (have_posts()) : the_post(); ?>
    <div class="ui container" id="content">

        <div class="ui basic segment headingc">
            <h1 class="ui header headerc">
                <?php echo get_the_title(); ?>
            </h1>
        </div>
        <div class="ui fitted divider"></div>

        <div class="ui basic segment" >
            <p class = "justifiedText" style = "text-align: justify !important;  
	text-justify: inter-word !important;">
               The Center for Complexity and Emerging Technologies (COMET) is a multidisciplinary research and professional laboratory at the College of Computer Studies that investigates the science of complex adaptive systems and explores innovative ways of interacting with computing solutions. Aside from performing research, the center also functions as a development laboratory for the creation of various civic computing solutions, integrating research done internally.
		  </p>
	  
	  <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">COMET is currently composed of lead researchers, cohorts, and research assistants. The lead researchers come from the fields of computing, statistics, mathematics and physics. The cohorts and research assistants are students from the different programs and specializations under the College of Computer Studies.
		  </p>
		  
		  <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
		
		COMET leverages its research in complex adaptive systems and computer-human interaction with the development of civic computing solutions. It also provides avenues for the professional growth of its lead researchers and cohorts.

            </p>

        </div>

        <!--            <div class="ui basic segment nospaces">-->
        <!--                <div class="ui stackable grid">-->
        <!--                    <div class="row">-->
        <!--                        <div class="sixteen wide column left">-->
        <h2 class="ui header comethead">
            Our Vision</h2>
        <div class="ui segment nospaces">

            <div class="ui two column grid">
                <div class="six wide column">
                    <img class="ui image featuredpic"
                         src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">
                </div>
                <div class="ten wide column">
                    <div class="ui basic segment noleftspace">
                        <p class = "justifiedText" style = "text-align: justify !important;  
	text-justify: inter-word !important;" >
                           The Center for Complexity and Emerging Technologies (COMET) envisions itself to become a leading research center that leverages on the science of complexity and computer-human interactions in creating emergent technologies for the benefit of society.

                        </p>
                    </div>
                </div>
            </div>
        </div>

	  
	  
	  
	    
	  
	  
        <!--                        </div>-->
        <!--                        <div class="sixteen wide column left">-->
        <h2 class="ui header comethead">
            Our Mission</h2>
        <div class="ui segment nospaces">
            <!---->
            <div class="ui two column grid">
                <div class="ten wide column">
                    <div class="ui basic segment">
                        <p class = "justifiedText" style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                            The center aims to contribute actively in the creation of new knowledge in the fields of complex adaptive systems, computer-human interaction and applied computing. We also challenge ourselves to rapidly apply the knowledge and technologies generated in collaboration with the public sector towards stimulating and significant outcomes.

                        </p>
                    </div>
                </div>
                <div class="six wide column">
                    <img class="ui right floated image featuredpic"
                         src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">
                </div>

            </div>
        </div>

        <br> <br>
 <br> <br>
<!--        <div class="ui very padded basic segment">-->
	  
	  
	  
	  
	  <div class="ui basic segment headingc">
            <h1 class="ui header headerc">
                Divisions
            </h1>
        </div>
	          <div class="ui fitted divider"></div>

	  <h2 class="ui header comethead">
            Complex Systems</h2>
	  <div class = "ui segment nospaces">
		<div class = "row">
		  	<div class = "ui segment string nospaces">
			  <div class="row">
				<img class="ui image fluid featuredpic" src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png"></div>
                    <div class="row">
                        <div class="ten wide column">
                           <div class="ui basic boxcontent">
                                <p style = "text-align: justify !important;  text-justify: inter-word !important;">
									Urban cities and metropolitan areas have steadily grown in size and capacity due to urban migration, thus making them increasingly harder to monitor and predict. Add to that the increasing complexity of the different interactions between varieties of structures and their socio-economic influences; we cannot rely solely on reductionist approaches, human instinct and experiences in managing current problems and planning future expansions and developments. With the vast amount and availability of data that public and private institutions have amassed as part of their operations and processes, representative models can be created to analyze and uncover a city’s emergent behaviors.
							    </p>
							 
							    <p style = "text-align: justify !important;  text-justify: inter-word !important;">
                                    Such modeling and simulation tools can make strides in supporting local and national governments make representative, sound and suitable planning decisions. Using models that rely on historical data, computing tools can be developed to better understand, manage and evaluate how dynamic systems, like cities, work, operate and live.
							    </p>
							 
							 	<p style = "text-align: justify !important;  text-justify: inter-word !important;">
									The Complex Systems research group aims to gather sufficient historical data that will help us understand the context of the current problems stunting the development of Metro Manila. The group also aims to build (a) models and tools that will eventually allow government units to effectively plan their urban landscape, such as the overcrowded mass transit and basic education facilities; and (b) a poverty indicator model that source its calculations from actual community-based data, among others. Key technologies and theories to be explored are in the areas of computational science, bioinformatics, simulation and modeling, complex networks, systems theory, nonlinear dynamics, and data mining.
							    </p>
                           </div>
                        </div>
                    </div>
			</div>
		</div>
	  </div>
	  
	  <br>
	  <h2 class="ui header comethead">
            Seamless Interfaces</h2>
	  <div class = "ui segment nospaces">
		<div class = "row">
		  	<div class = "ui segment string nospaces">
			  <div class="row">
				<img class="ui image fluid featuredpic" src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png"></div>
                    <div class="row">
                        <div class="ten wide column">
                           <div class="ui basic boxcontent">
                                <p style = "text-align: justify !important;  text-justify: inter-word !important;">
									According to the World Economic Forum held last January 2016, we are on the brink of a 4th Industrial Revolution that builds upon the digital revolution brought about by the 3rd Industrial Revolution since the middle of the last century. We will slowly see cyber-physical systems that will blur the lines between the physical, digital and biological spheres.
							 </p>
							 	<p style = "text-align: justify !important;  text-justify: inter-word !important;">
									The Seamless Interfaces research group aims to build upon and contribute to this future of computational systems by (a) investigating the different ways we interact with digital information and services, and; (b) designing and building interfaces that are intuitive and well integrated into our daily lives, providing better insights and strengthening interpersonal connections. The goal is to provide interfaces that allow seamless transitions between the physical and digital spaces.
							    </p>
							 <p style = "text-align: justify !important;  text-justify: inter-word !important;">
									The Seamless Interfaces research group aims to be a pioneer in research in computer human interaction in the Philippines. It shall lead in the discovery of interfaces, interactions and frameworks that innovate existing solutions. Specifically, the division shall generate and contribute to the: 
							    </p>
							 
							 
							 <div class="ui list relaxed">
								<a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">discovery of interfaces and interactions that enable faster computer-human interaction</div>
<!--									<div class="description">This text will always have a left margin to make sure it sits alongside your icon</div>
--><!---->								  
								    </div>
								</a>
							   <a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">design of frameworks that enable an improved social media, human and computer interaction</div>					  
								    </div>
								</a>
							   <a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">integration of innovative sensor and intelligent technology towards the creation of ubiquitous computing environments</div>					  
								    </div>
								</a>
							 </div>
							 
							
							 <p style = "text-align: justify !important;  text-justify: inter-word !important;">
									The Seamless Interfaces research group shall partake and engage themselves in research towards evaluating existing user problems and experiences. It shall lead in conducting user experience research, develop and implement prototypes using sensors, advanced tools and new media. The Seamless Interfaces division partakes in the following research activities:
							    </p>

							 
							 <div class="ui list very relaxed" >
							   <a class="item noDecoration" >
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="header" style= "text-decoration: none !important;">Ambient Computing</div>
									<div class="description">the development of spaces and its sensors that enable the most hassle-free computer-human interaction in the delivery of the regular duties of its users that is natural and on the terms of the target users. </div>
								  
								    </div>
								</a>
							   <a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="header">Augmented and Virtual Reality for Civic Services</div>
									<div class="description">the immersion of users in versions of realities that enable the research group to understand and model human activities performing specific tasks</div>
								  
								    </div>
								</a><a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="header">Sensor-driven interface development</div>
									<div class="description">the design and development of interfaces based on multiple, unexplored or alternative sources of inputs towards having the most seamless interface for a certain human task</div>
								  
								    </div>
								</a>
							   <a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="header">Intelligent, Unobtrusive and Context-Aware Processing</div>
									<div class="description">the analysis and study of user actions, decisions and movements based on available minable data</div>
								  
								    </div>
								</a>
							   
							 </div>
							 
                           </div>
                        </div>
                    </div>
			</div>
		</div>
	  </div>
	  
	
	  
	  <br>
	  <h2 class="ui header comethead">
            Complex Systems</h2>
	  <div class = "ui segment nospaces">
		<div class = "row">
		  	<div class = "ui segment string nospaces">
			  <div class="row">
				<img class="ui image fluid featuredpic" src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png"></div>
                    <div class="row">
                        <div class="ten wide column">
                           <div class="ui basic boxcontent">
                                <p style = "text-align: justify !important;  text-justify: inter-word !important;">
The increased use in mobile and internet technologies can be utilized to promote stronger civic participation and improve the flow of information and services from the providers to their target beneficiaries. At the Center for Complexity and Emerging Technologies, systems are being developed to provide a platform that can run on the cloud to serve the following needs:							    </p>
							  <div class="ui list very relaxed">
								<a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">Creation of a disaster preparedness tool that provides vital information on the different hazards that a household is exposed to given their current location and guides them in preparing for and reducing their predicted effects.
</div>
								    </div>
								</a>
								
								
								<a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">Maintenance of a directory of local researchers who are working on genome sequences to motivate collaborative research;
</div>
								    </div>
								</a>
								
								
								<a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">Collection of public sentiments (through social networks) on various government programs and services; data from this source can then be fed to text processing tools developed at the Center for Language Technologies, such as opinion mining and sentiment analysis;</div>
								    </div>
								</a>
								
								<a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">Processing and visualization of community-based monitoring system (CBMS) data sourced from data.gov.ph and the CBMS project of Angelo King Institute of Economic and Business Studies</div>
								    </div>
								</a>
								
								<a class="item noDecoration">
								  <i class="right triangle icon"></i>
								  <div class="content">
									<div class="description">Monitoring the performance of elected officials in the national and local levels to promote transparency and accountability
</div>
								    </div>
								</a>
							 </div>
							 
                           </div>
                        </div>
                    </div>
			</div>
		</div>
	  </div>
	  
	  
	  
	  
	  
           <!-- <div class="ui three column relaxed grid">
                <div class="column">

                    <div class="ui segment strong nospaces">
                        <div class="row">
                            <img class="ui image featuredpic"
                                 src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">

                        </div>
                        <div class="row">
                            <div class="ten wide column">
                                <div class="ui basic boxcontent">
                                    <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                                       The Complex Systems research group aims to gather sufficient historical data that will help us understand the context of the current problems stunting the development of Metro Manila. The group also aims to build (a) models and tools that will eventually allow government units to effectively plan their urban landscape, such as the overcrowded mass transit and basic education facilities; and (b) a poverty indicator model that source its calculations from actual community-based data, among others..
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column">

                    <div class="ui segment strong nospaces">
                        <div class="row">
                            <img class="ui image featuredpic"
                                 src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">

                        </div>
                        <div class="row">
                            <div class="ten wide column">
							  <div class="ui basic boxcontent">
                                    <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                                        The Seamless Interfaces research group aims to build upon and contribute to this future of computational systems by (a) investigating the different ways we interact with digital information and services, and; (b) designing and building interfaces that are intuitive and well integrated into our daily lives, providing better insights and strengthening interpersonal connections. The goal is to provide interfaces that allow seamless transitions between the physical and digital spaces.

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column">

                    <div class="ui segment strong nospaces">
                        <div class="row">
                            <img class="ui image featuredpic"
                                 src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">

                        </div>
                        <div class="row">
                            <div class="ten wide column">
                                <div class="ui basic boxcontent">
                                    <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                                        The increased use in mobile and internet technologies can be utilized to promote stronger civic participation and improve the flow of information and services from the providers to their target beneficiaries. At the Center for Complexity and Emerging Technologies, systems are being developed to provide a platform that can run on the cloud to serve the following needs.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
<!--        </div>-->

        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->

        <!--            </div>-->

    </div>


<?php
//    endwhile;
//endif;
wp_reset_postdata();
get_footer();
?>