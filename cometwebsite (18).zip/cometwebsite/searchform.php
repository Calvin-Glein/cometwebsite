<form role="search" method="get" action="<?php echo home_url( '/' ); ?>">
	





<div class="ui search">
  <div class="ui icon input">
    <input class="prompt" type="text" placeholder="Search" value="<?php echo get_search_query() ?>" name = "s" 	title="Search" />

    <i class="search icon"></i>
  </div>
  <div class="results"></div>
</div> 	


</form>
</div>