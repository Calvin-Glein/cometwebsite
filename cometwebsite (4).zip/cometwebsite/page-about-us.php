<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/13/2016
 * Time: 9:53 AM
 */

get_header();
?>


<?php //if (have_posts()) : ?>
    <!--    --><?php //while (have_posts()) : the_post(); ?>
    <div class="ui container" id="content">

        <div class="ui basic segment headingc">
            <h1 class="ui header headerc">
                <?php echo get_the_title(); ?>
            </h1>
        </div>
        <div class="ui fitted divider"></div>

        <div class="ui basic segment" >
            <p class = "justifiedText" style = "text-align: justify !important;  
	text-justify: inter-word !important;">
               The Center for Complexity and Emerging Technologies (COMET) is a multidisciplinary research and professional laboratory at the College of Computer Studies that investigates the science of complex adaptive systems and explores innovative ways of interacting with computing solutions. Aside from performing research, the center also functions as a development laboratory for the creation of various civic computing solutions, integrating research done internally.
		  </p>
	  
	  <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">COMET is currently composed of lead researchers, cohorts, and research assistants. The lead researchers come from the fields of computing, statistics, mathematics and physics. The cohorts and research assistants are students from the different programs and specializations under the College of Computer Studies.
		  </p>
		  
		  <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
		
		COMET leverages its research in complex adaptive systems and computer-human interaction with the development of civic computing solutions. It also provides avenues for the professional growth of its lead researchers and cohorts.

            </p>

        </div>

        <!--            <div class="ui basic segment nospaces">-->
        <!--                <div class="ui stackable grid">-->
        <!--                    <div class="row">-->
        <!--                        <div class="sixteen wide column left">-->
        <h2 class="ui header comethead">
            Our Vision</h2>
        <div class="ui segment nospaces">

            <div class="ui two column grid">
                <div class="six wide column">
                    <img class="ui image featuredpic"
                         src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">
                </div>
                <div class="ten wide column">
                    <div class="ui basic segment noleftspace">
                        <p class = "justifiedText" style = "text-align: justify !important;  
	text-justify: inter-word !important;" >
                           The Center for Complexity and Emerging Technologies (COMET) envisions itself to become a leading research center that leverages on the science of complexity and computer-human interactions in creating emergent technologies for the benefit of society.

                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!--                        </div>-->
        <!--                        <div class="sixteen wide column left">-->
        <h2 class="ui header comethead">
            Our Mission</h2>
        <div class="ui segment nospaces">
            <!---->
            <div class="ui two column grid">
                <div class="ten wide column">
                    <div class="ui basic segment">
                        <p class = "justifiedText" style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                            The center aims to contribute actively in the creation of new knowledge in the fields of complex adaptive systems, computer-human interaction and applied computing. We also challenge ourselves to rapidly apply the knowledge and technologies generated in collaboration with the public sector towards stimulating and significant outcomes.

                        </p>
                    </div>
                </div>
                <div class="six wide column">
                    <img class="ui right floated image featuredpic"
                         src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">
                </div>

            </div>
        </div>

        <br> <br>
 <br> <br>
<!--        <div class="ui very padded basic segment">-->
            <div class="ui three column relaxed grid">
                <div class="column">

                    <div class="ui segment strong nospaces">
                        <div class="row">
                            <img class="ui image featuredpic"
                                 src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">

                        </div>
                        <div class="row">
                            <div class="ten wide column">
                                <div class="ui basic boxcontent">
                                    <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                                       The Complex Systems research group aims to gather sufficient historical data that will help us understand the context of the current problems stunting the development of Metro Manila. The group also aims to build (a) models and tools that will eventually allow government units to effectively plan their urban landscape, such as the overcrowded mass transit and basic education facilities; and (b) a poverty indicator model that source its calculations from actual community-based data, among others..
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column">

                    <div class="ui segment strong nospaces">
                        <div class="row">
                            <img class="ui image featuredpic"
                                 src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">

                        </div>
                        <div class="row">
                            <div class="ten wide column">
							  <div class="ui basic boxcontent">
                                    <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                                        The Seamless Interfaces research group aims to build upon and contribute to this future of computational systems by (a) investigating the different ways we interact with digital information and services, and; (b) designing and building interfaces that are intuitive and well integrated into our daily lives, providing better insights and strengthening interpersonal connections. The goal is to provide interfaces that allow seamless transitions between the physical and digital spaces.

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column">

                    <div class="ui segment strong nospaces">
                        <div class="row">
                            <img class="ui image featuredpic"
                                 src="http://128.199.182.88/wp-content/uploads/2017/01/filler.png">

                        </div>
                        <div class="row">
                            <div class="ten wide column">
                                <div class="ui basic boxcontent">
                                    <p style = "text-align: justify !important;  
	text-justify: inter-word !important;">
                                        The increased use in mobile and internet technologies can be utilized to promote stronger civic participation and improve the flow of information and services from the providers to their target beneficiaries. At the Center for Complexity and Emerging Technologies, systems are being developed to provide a platform that can run on the cloud to serve the following needs.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
<!--        </div>-->

        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->

        <!--            </div>-->

        <div class="ui basic segment"></div>
    </div>


<?php
//    endwhile;
//endif;
wp_reset_postdata();
get_footer();
?>