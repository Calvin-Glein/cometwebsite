<footer class="site-footer footer">

    <div class="ui container ">

        <!--        <div class="ui basic center aligned segment">-->
        <!--            <a href="#" class="footerlink">Facebook</a> | <a href="#" class="footerlink">Github</a> | <a href="#"-->
        <!--                                                                                                         class="footerlink">Gmail</a>-->
        <!--            <img class="ui image centered tiny" style="padding-top: 25px !important;"-->
        <!--                 src="http://localhost:4040/wordpress/wp-content/uploads/2016/06/SHORT-WHITE.png">-->
        <!--            --><?php //wp_footer(); ?>
        <!--        </div>-->

        <div class="ui grid">
            <div class="three wide column">
                <h3 class="ui header"><a href="<?php bloginfo('url'); ?>" class="headlink">COMET</a></h3>
                <a href="<?php bloginfo('url'); ?>" class="whitelink"><h5 class="ui header whitelink">Home</h5></a>
                <a href="<?php bloginfo('url'); ?>/about-us" class="whitelink"><h5 class="ui header whitelink">About Us</h5></a>
                <a href="<?php bloginfo('url'); ?>/sponsorship" class="whitelink"><h5 class="ui header whitelink">Sponsorship</h5></a>
                <a href="<?php bloginfo('url'); ?>/events" class="whitelink"><h5 class="ui header whitelink">Events</h5></a>
                <a href="<?php bloginfo('url'); ?>/news" class="whitelink"><h5 class="ui header whitelink">News</h5></a>
            </div>
            <div class="three wide column">
                <h3 class="ui header"><a href="<?php bloginfo('url'); ?>/projects" class="headlink">Projects</a></h3>
                <a href="<?php bloginfo('url'); ?>/projects/development" class="whitelink"><h5 class="ui header whitelink">Development</h5></a>
                <a href="<?php bloginfo('url'); ?>/projects/research" class="whitelink"><h5 class="ui header whitelink">Research</h5></a>
            </div>
            <div class="three wide column">
                <h3 class="ui header"><a href="<?php bloginfo('url'); ?>/people" class="headlink">People</a></h3>
                <a href="<?php bloginfo('url'); ?>/people/faculty" class="whitelink"><h5 class="ui header whitelink">Faculty</h5></a>
                <a href="<?php bloginfo('url'); ?>/people/cohorts" class="whitelink"><h5 class="ui header whitelink">Cohorts</h5></a>
                <a href="<?php bloginfo('url'); ?>/people/alumni" class="whitelink"><h5 class="ui header whitelink">Alumni</h5></a>
            </div>
            <div class="three wide column">
                <h3 class="ui header headlink">Networks</h3>
			  
			   		   
			  
			  <a href="https://github.com/dlsucomet" class="ui mini image clickable">
				<img src="http://128.199.182.88/wp-content/uploads/2017/01/github.png">
			  </a>
			  <a href="https://www.facebook.com/dlsucomet/" class="ui mini image clickable"> 
				<img src="http://128.199.182.88/wp-content/uploads/2017/01/facebook.png">
			  </a>
			 <!--  <a href="https://www.facebook.com/dlsucomet/" class="ui mini image clickable">
				<img src="http://128.199.182.88/wp-content/uploads/2017/01/twitter.png">
			  </a>--><!---->
			  
        
            </div>
            <div class="four wide column">
			   <img class="ui image centered small"
               src="http://128.199.182.88/wp-content/uploads/2017/01/SHORT-WHITE.png">   
            </div>
		 
        </div>

    </div>


</footer>
</body>
</html>