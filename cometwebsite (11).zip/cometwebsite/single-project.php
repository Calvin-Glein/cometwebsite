<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/13/2016
 * Time: 9:53 AM
 */

get_header();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <div class="ui container" id="content">


        <div class="ui grid">
            <div class="five wide column">

                <?php if (has_post_thumbnail()) { ?><img class="ui image rounded large"
                                                         src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>"> <?php } ?>
                <br>

			  
			  <b>Division:</b>
					<?php the_field('division'); ?> 			  
			  
			  <br>
                <b>Tags:</b>
                     <?php the_tags( '', ', ', '<br />' ); ?>		
			  
			  <br>
			  

			  
			  

<?php if (strcasecmp(get_field('status'), "Maintenance") == 0) echo "<div class=\"ui gray progress\" data-percent=\"100\""; ?>
<?php if (strcasecmp(get_field('status'), "For Publishing") == 0) echo "<div class=\"ui gray progress\" data-percent=\"90\""; ?>
<?php if (strcasecmp(get_field('status'), "Active") == 0) echo "<div class=\"ui gray progress\" data-percent=\"50\""; ?>
<?php if (strcasecmp(get_field('status'), "On Hold") == 0) echo "<div class=\"ui gray progress disabled\" data-percent=\"30\""; ?>
<?php if (strcasecmp(get_field('status'), "Stopped") == 0) echo "<div class=\"ui progress error\" "; ?>
<?php if (strcasecmp(get_field('status'), "Proposed") == 0) echo "<div class=\"ui gray progress stopped\" data-percent=\"10\""; ?>


" id="statusbar">
				<div class="bar"></div>
			   <div class="label">Status: <?php the_field('status'); ?> </div>
			  </div>
			  
			  <script> $('#statusbar').progress(); </script>
			  
			  
<!--			<?php if (strcmp(get_the_title(), $temp) != 0) echo "basic "; ?>
--><!---->

			  
                <h3 class="ui header dividing">Team Members</h3>
                <div class="ui vertical list">
                    <?php
                    // Find connected weeks
                    $connected = new WP_Query(array(
                        'connected_type' => 'working', // the name of your connection type
                        'connected_items' => get_queried_object(),
                        'nopaging' => true,
                    ));

                    if ($connected->have_posts()) : ?>
				    <div class="ui mini steps vertical fluid ">

                        <?php while ($connected->have_posts()) : $connected->the_post(); ?>
				  
  <div class="step clickable" onclick="location.href = '<?php the_permalink(); ?>';">
    <i class="user icon"></i>
    <div class="content">
      <div class="title"><?php echo get_the_title(); ?></div>
      <div class="description"> <?php $categories = get_the_category();
                                    echo esc_html($categories[0]->name); ?></div>
    </div>
  </div>

	  
				  
				  
                        <?php endwhile; ?>
                        <?php
                        // Prevent weirdness
                        wp_reset_postdata();
                    endif;
                    ?>

                </div>
			  
</div>
			  
		
			  
                           <!-- <div class="item clickable" onclick="location.href = '<?php the_permalink(); ?>';">
                                <img class="ui mini rounded image"
                                     src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" style = "height: 50px; width = auto;" >
                                <div class="content">
                                    <div class="ui sub header proponents" ><?php echo get_the_title(); ?></div>
                                    <?php $categories = get_the_category();
                                    echo esc_html($categories[0]->name); ?>
                                </div>
                            </div>
			  --><!---->
			
			     
		  
			  
			  
			  


            </div>
            <div class="eleven wide column">
                <h1 class="ui header dividing" ><?php echo get_the_title(); ?></h1>
                <div style = "text-align: justify; text-justify: inter-word;" ><?php the_content(); ?></div>
          
			  
              
                <h2 class="ui header dividing">Events and News</h2>
				   
			  
			  
			  			   <div class="ui link cards">

			     <?php if (have_rows('timeline')):

                                        $j=0;
                                        // loop through the rows of data
                                        while (have_rows('timeline')) : the_row();

                                            // display a sub field value
                                            ?>
                                            
					  
			  <div class="card"  onclick="location.href = '<?php the_sub_field('link');?>';" >
				<div class="content">
				  <div class="header"><?php the_sub_field('checkpoint');?></div>
				 
				  <div class="description">
					<?php the_sub_field('date');?>				  </div>
				</div>
			
			  </div>
			  

 
  <?php
                                        $j++;
                                        endwhile;

                                    endif;

                                    ?>
			  
			  
			</div>

			  

			  
			  
			  
			  
			  
			  
            </div>
		  
		  
		  
				  
	
        </div>

    </div>

<?php
endwhile;
endif;
get_footer();
?>