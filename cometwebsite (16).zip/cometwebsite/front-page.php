<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/11/2016
 * Time: 12:18 AM
 */

get_header();
?>
    <div class="ui container" id="content">
        <div class="uk-slidenav-position heavybottom" data-uk-slideshow="{autoplay:true, animation: 'swipe'}">
            <ul class="uk-slideshow  uk-overlay-active">
                <?php
                $loop = new WP_Query(array('post_type' => 'any', 'category_name' => 'featured'));
                if ($loop->have_posts()) :
                    while ($loop->have_posts()) : $loop->the_post(); ?>
                        <?php if (has_post_thumbnail()) { ?>
                            <li class = " clickable" onclick="location.href='<?php the_permalink(); ?>'">
                                <!--                                    <a href="--><?php //the_permalink(); ?><!--">-->
                                <img class="ui image coverpic"
                                     src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>">
                                <!--                                        <a href="-->
                                <?php //the_permalink(); ?><!--">--><?php //the_post_thumbnail(); ?><!--</a>-->
                                <!--                                     </a>-->
                                <figcaption 
                                    class="uk-overlay-panel uk-overlay-right uk-overlay-background uk-overlay-fade"
                                    style="width: 25%"><h3><?php echo get_the_title(); ?></h3>
                                    <p style  = "text-align: justify; text-justify: inter-word;"><?php echo wp_strip_all_tags(excerpt(40)); ?></p></figcaption>
                                <!--                                        <figcaption class="uk-overlay-panel uk-overlay-right uk-overlay-background uk-overlay-fade" style="width: 25%"><h3>hi</h3><p>hello</p></figcaption>-->

                            </li>
                        <?php } ?>
                    <?php endwhile;
                endif;
                wp_reset_postdata();
                ?>
            </ul>
            <a href="" class="uk-slidenav uk-slidenav-contrast uk-slidenav-previous"
               data-uk-slideshow-item="previous"></a>
            <a href="" class="uk-slidenav uk-slidenav-contrast uk-slidenav-next" data-uk-slideshow-item="next"></a>
            <ul class="uk-dotnav uk-dotnav-contrast uk-position-bottom uk-flex-center">
                <li data-uk-slideshow-item="0"><a href=""></a></li>
                <li data-uk-slideshow-item="1"><a href=""></a></li>
			     <li data-uk-slideshow-item="2"><a href=""></a></li>
            </ul>
        </div>

        <div class="ui basic segment nospaces">
            <div class="ui stackable grid">
                <div class="row">
                    <div class="eight wide column left">


                        <h1 class="ui header comethead" style = "margin-bottom: 20px;">
						  <a href="http://128.199.182.88:8080/?page_id=84" class = "featuredCard" style = " text-decoration:none; font-weight: bold;
" >
 							 <b>Development</b>
				</a>
					
						
						  <!--
						  <div class="ui basic buttons right floated" >
							<div class="ui button" onclick="location.href = 'http://128.199.182.88:8080/?page_id=84';" >View all  &nbsp; &nbsp; > </div>
						  </div>--><!---->
						  
						  
						  <div class="ui animated button right floated basic" tabindex="0">
  <div class="visible content">View all</div>
  <div class="hidden content">
    <i class="chevron right icon"></i>
  </div>
</div>
						  
						  
						
			</h1>

					  
					  <?php
                                $temp = new WP_Query(array('post_type' => 'project', 'category_name' => 'development'));
                                if ($temp->have_posts()) {
                                        $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                        endwhile;?>

                        <div class="ui strong nospaces  clickable" onclick="location.href='<?php the_permalink(); ?>'">

						              <?php  }
                                wp_reset_postdata(); ?>
						  
                            <div class="ui two column grid">

                                <?php
                                $temp = new WP_Query(array('post_type' => 'project', 'category_name' => 'development'));
                                if ($temp->have_posts()) {
                                        $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                        endwhile;?>

                                        <div class="column">
                                            <?php if (has_post_thumbnail()) { ?>
										  

										  
										  <img class="ui image rounded featuredpic" style ="margin-left:15px;"
                                                     src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>">
                                            <?php } ?>
                                        </div>
                                        <div class="column">
                                            <div class = "ui basic segment noleftspace">
                                            <h2 class="ui header" style="margin-top: 0 "><?php echo the_title(); ?>
                                            </h2>
											  <div class="ui divider"></div>
                                            <p style = "text-align: justify; text-justify: inter-word;">
                                                <?php echo excerpt(40); ?>
                                            </p>
                                                </div>
                                        </div>

                                    <?php  }
                                wp_reset_postdata(); ?>
                            </div>
                        </div>

                    </div>
                    <div class="eight wide column right">
                        <h1 class="ui header comethead">
						  <a href="http://128.199.182.88:8080/?page_id=88" class = "featuredCard " style = " text-decoration:none; font-weight: bold;
">
  <b>Research</b>
				</a>
						  
						  <div class="ui basic buttons right floated">
  							<div class="ui button"  onclick="location.href = 'http://128.199.182.88:8080/?page_id=88';"  >View all  &nbsp; &nbsp; > </div>
						  </div>
                        </h1>

					  
  <?php
                                $temp = new WP_Query(array('post_type' => 'project', 'category_name' => 'research'));
                                if ($temp->have_posts()) {
                                        $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                        endwhile;?>

                        <div class="ui strong nospaces  clickable" onclick="location.href='<?php the_permalink(); ?>'">

						              <?php  }
                                wp_reset_postdata(); ?>
						  					  
                            <div class="ui two column grid">

                                <?php
                                $temp = new WP_Query(array('post_type' => 'project', 'category_name' => 'research'));
                                if ($temp->have_posts()) {
                                    $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                    endwhile;?>

                                    <div class="column">
                                        <?php if (has_post_thumbnail()) { ?>
                                            <img class="ui image rounded featuredpic" style ="margin-left:15px;"
                                                 src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>">
                                        <?php } ?>
                                    </div>
                                    <div class="column">

                                        <div class = "ui basic segment noleftspace">
                                        <h2 class="ui  header" style="text-decoration:none; margin-top: 0"><?php echo the_title(); ?>
                                        </h2>
										  											  <div class="ui divider"></div>

                                        <p style = "text-align: justify; text-justify: inter-word;">
                                            <?php echo excerpt(40); ?>
                                        </p>
                                            </div>
                                    </div>

                                <?php  }
                                wp_reset_postdata(); ?>
                            </div>
                        </div>
                    </div>
                </div>
			  
			  
			  
			  
			  
			  <div class="row" style = "margin-top:20px">
                    <div class="eight wide column left">
                        <h1 class="ui header comethead">
						  <a href="http://128.199.182.88:8080/?page_id=115" class = "featuredCard " style = " text-decoration:none; font-weight: bold;
">
  <b> News </b>
			    </a>
						  
						  <div class="ui basic buttons right floated">
  							<div class="ui button"  onclick="location.href = 'http://128.199.182.88:8080/?page_id=115';" >View all &nbsp; &nbsp; > </div>
						  </div>
			</h1>

					  
					    <?php
                                $temp = new WP_Query(array('post_type' => 'updates'));
                                if ($temp->have_posts()) {
                                        $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                        endwhile;?>

                        <div class="ui strong nospaces  clickable" onclick="location.href='<?php the_permalink(); ?>'">

						              <?php  }
                                wp_reset_postdata(); ?>
						  
                            <div class="ui two column grid">

                                <?php
                                $temp = new WP_Query(array('post_type' => 'updates'));
                                if ($temp->have_posts()) {
                                    $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                    endwhile;?>

                                    <div class="column">
                                        <?php if (has_post_thumbnail()) { ?>
                                            <img class="ui image rounded featuredpic" style ="margin-left:15px;"
                                                 src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>">
                                        <?php } ?>
                                    </div>
                                    <div class="column">

                                        <div class = "ui basic segment noleftspace">
                                        <h2 class="ui  header" style="text-decoration:none; margin-top: 0"><?php echo the_title(); ?>
                                        </h2>
										  
										  											  <div class="ui divider"></div>

                                        <p style = "text-align: justify; text-justify: inter-word;">
                                            <?php echo excerpt(40); ?>
                                        </p>
                                            </div>
                                    </div>

                                <?php  }
                                wp_reset_postdata(); ?>
                            </div>
                        </div>
                    </div>


 	


                    <div class="eight wide column right">

                        <h1 class="ui header comethead">
						  <a href="http://128.199.182.88:8080/?page_id=353" class = "featuredCard " style = " text-decoration:none; font-weight: bold;
">
  <b>Events</b>
				</a>
						  
						  <div class="ui basic buttons right floated">
  							<div class="ui button"  onclick="location.href = 'http://128.199.182.88:8080/?page_id=353';" >View all&nbsp; &nbsp; > </div>
						  </div>
                            </h1>
					  
  <?php
                                $temp = new WP_Query(array('post_type' => 'event'));
                                if ($temp->have_posts()) {
                                        $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                        endwhile;?>

                        <div class="ui strong nospaces  clickable" onclick="location.href='<?php the_permalink(); ?>'">

						              <?php  }
                                wp_reset_postdata(); ?>
						  
                            <div class="ui  two column  grid">

                                <?php
                                $temp = new WP_Query(array('post_type' => 'event'));
                                if ($temp->have_posts()) {
                                    $temp->the_post();

                                    while ($temp->have_posts() && !has_post_thumbnail()) : $temp->the_post();
                                    endwhile;?>

                                    <div class="column">
                                        <?php if (has_post_thumbnail()) { ?>
                                            <img class="ui image rounded featuredpic" style ="margin-left:15px;"
                                                 src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>">
                                        <?php } ?>
                                    </div>
                                    <div class="column">
                                        <div class = "ui basic segment noleftspace">
                                            <h2 class="ui  header" style="text-decoration:none; margin-top: 0"><?php echo the_title(); ?>
                                            </h2>
										  											  <div class="ui divider"></div>

                                            <p style = "text-align: justify; text-justify: inter-word;">
                                                <?php echo excerpt(40); ?>
                                            </p>
                                        </div>

                                    </div>

                                <?php  }
                                wp_reset_postdata(); ?>
                            </div>



                        </div>


                    </div>
                </div>
            </div>
        </div>
        <div class="ui basic segment"></div>
    </div>

<?php

get_footer();

?>
