<?php
/**
 * Created by PhpStorm.
 * User: rissa
 * Date: 6/13/2016
 * Time: 9:53 AM
 */

get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <div class="ui container" id="content">


        <div class="ui grid">
            <div class="five wide column">

                <?php if (has_post_thumbnail()) { ?><img class="ui image rounded large"
                                                         src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>"> <?php } ?>

                <?php if(in_category('faculty')) { ?>
                    <br>
                    <b>Rank: </b> <?php the_field('rank'); ?> <br><br>
                    <b>Research Fields: </b>  <?php if (have_rows('field')):

                        // loop through the rows of data
                        while (have_rows('field')) : the_row();
                            ?>

<!--                            <span class="ui basic label">-->
                            <?php the_sub_field('research'); ?>
<!--                        </span>-->
                            <?php
                        endwhile;

                    endif;

                }
                else{?>
                    <br>
                  <!--  <b>Batch: </b> <?php the_field('batch'); ?> <br>
                    <b>Degree: </b> <?php the_field('degree'); ?> <br>
			        <b>Email: </b> <?php the_field('email'); ?> <br>--><!---->

			  
			  
			  

			  			<table class="ui very basic collapsing celled table">
							<!--<thead>
							  <tr><th>Employee</th>
							  <th>Correct Guesses</th>
							</tr></thead>--><!---->
							<tbody>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="university icon"></i>
									<div class="content">
									  Batch
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('batch'); ?>
								</td>
							  </tr>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="student icon"></i>
									<div class="content">
									  Degree
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('degree'); ?>
								</td>
							  </tr>
							  <tr>
								<td>
								  <h4 class="ui image header">
									<i class="mail outline icon"></i>
									<div class="content">
									  Email
									  <div class="sub header">
									</div>
								  </div>
								</h4></td>
								<td>
								  <?php the_field('email'); ?>
								</td>
							  </tr>
							  
							</tbody>
						  </table>


                    <?php
                }
                ?>
            </div>
            <div class="eleven wide column">
                <h1 class="ui header "><?php echo get_the_title(); ?><div class = "ui fitted divider"></div></h1>
			  	  	 	  

                <div style = "text-align: justify; text-justify: inter-word;"> <?php the_content(); ?> </div>

                <?php if (in_category('faculty')) { ?>



                    <h2 class="ui header">Papers<div class = "ui fitted divider"></div></h2>
                    <div class="ui three column grid" style="margin-top: 10px">


                    <?php
                    $paperz = new WP_Query(array(
                        'connected_type' => 'researched', // the name of your connection type
                        'connected_items' => get_queried_object(),
                        'nopaging' => true,
                    ));


                    p2p_type('researched')->each_connected($paperz, array(), 'members');

                    if ($paperz->have_posts()) : ?>

                        <?php while ($paperz->have_posts()) :
                            $paperz->the_post(); ?>


                            <div class="column">
                                <div class="ui card">
                                    <div class="content">
                                        <div class="header"><?php echo the_title(); ?></div>
                                        <div class="description">
                                            <?php echo get_the_content(); ?>
                                        </div>
                                    </div>
                                    <a href="<?php the_field('link'); ?>" class="ui bottom attached button">
                                        View Paper

                                    </a>
                                </div>


                            </div>

                            

                        <?php endwhile; endif;
                } ?>

                <h2 class="ui header ">Projects<div class = "ui fitted divider"></div></h2>

                <div class="ui two column grid" style="margin-top: 10px">


                    <?php
                    // Find connected weeks
                    $connected = new WP_Query(array(
                        'connected_type' => 'working', // the name of your connection type
                        'connected_items' => get_queried_object(),
                        'nopaging' => true,
                    ));


                    p2p_type('working')->each_connected($connected, array(), 'members');

                    if ($connected->have_posts()) : ?>

                        <?php while ($connected->have_posts()) :
                            $connected->the_post(); ?>

                            <div class="column">
                                <div class="ui card clickable" onclick="location.href='<?php the_permalink(); ?>'">
								  
								  
                                    <div class="content">
									  
									  <div class = "ui grid">
										
										
									  <div class = "five wide column">
									   <?php if (has_post_thumbnail()) { ?><img class="ui image rounded small"
                                                         src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>"> <?php } ?>

									   </div>
										
										<div class = "seven wide column">
										  
										  
										 <!-- <h3 class="ui header" style = "padding-top: 10px;" ><b><?php echo the_title(); ?></b>
										  
												<div class="meta">
											  
													 <span class="category"><?php echo p2p_get_meta($post->p2p_id, 'role', true); ?></span>
											</div>
										  
										  
										  
										  
										  </h3>--><!---->
										  
										  
										<div class="content" style = "padding-top: 10px;" >
											<h3 class="ui header medium"><?php echo the_title(); ?>
											  
											  
											  <div class="meta">
											  <a><?php echo p2p_get_meta($post->p2p_id, 'role', true); ?></a>
											</div>
											  
											 </h3>
											
										  </div>
										  
										  
											
										</div>
										
									  										<div class = "four wide column">

										  
										  
										  <?php if (in_category('research')) { ?><span
                                            class="ui blue right ribbon label"><?php $categories = get_the_category();
                                            echo esc_html($categories[0]->name); ?></span>
                                        <?php } else { ?><span
                                            class="ui orange right ribbon label"><?php $categories = get_the_category();
                                            echo esc_html($categories[0]->name); ?></span> <?php } ?>
										  
										  
									
										    
										  
										</div>
						
										
										
										
                                      

                                       
										
										
									  </div>
									  
									  <br>
									  
                                        <div class="description" style = "text-align: justify; text-justify: inter-word;">
										  
                                            <?php echo get_the_excerpt(); ?>
                                        </div>
                                    </div>
                                    <div class="extra content">
                                        <?php
                                        foreach ($post->members as $post) : setup_postdata($post);
                                            ?>

                                            <div class="right floated author">
                                                <a href="<?php echo the_permalink(); ?>"><img class="ui avatar image"
                                                                                              title="<?php echo get_the_title(); ?>"
                                                                                              alt="<?php echo get_the_title(); ?>"
                                                                                              src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" 
																							  data-title="<?php echo get_the_title(); ?>"
																							data-content="<?php echo p2p_get_meta($post->p2p_id, 'role', true); ?>"
												  											 data-position="bottom right"
												  											data-variation = "inverted"
												  >

																									</a>
											  
                                            </div>

                                            <?php
                                        endforeach;

                                        wp_reset_postdata();
                                        ?>

                                    </div>
                                </div>
                            </div>
				  
				  
				  
				  <script>
					$('.ui.avatar.image')
					   .popup({
						inline: true
					  })
					;
				  </script>
                        <?php endwhile; ?>
                        <?php
                        // Prevent weirdness
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
            </div>

        </div>

		  <br>
		  <br>
		  

    </div>

    <?php
endwhile;
endif;
get_footer();
?>